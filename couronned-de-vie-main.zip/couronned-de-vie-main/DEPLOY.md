# 🚀 Guide de Déploiement - GitHub Pages

Guide rapide pour déployer l'application **Couronne de Vie - Gestion des Recettes de Taxi** sur GitHub Pages.

## 📝 Prérequis

- Un compte GitHub (gratuit)
- Tous les fichiers du projet

## 🎯 Déploiement en 5 étapes

### Étape 1 : Créer le dépôt GitHub

1. Connectez-vous à [github.com](https://github.com)
2. Cliquez sur le **+** en haut à droite → **New repository**
3. Remplissez :
   - **Repository name** : `couronne-de-vie` (ou autre nom)
   - **Description** : "Application de gestion de recettes de taxi"
   - **Visibilité** : Public ou Private
   - ⚠️ **Ne cochez PAS** "Add a README file"
4. Cliquez sur **Create repository**

### Étape 2 : Préparer les fichiers localement

Assurez-vous d'avoir ces fichiers dans votre dossier :
```
Couronne de Vie/
├── index.html
├── styles.css
├── app.js
├── README.md
├── .gitignore
├── .nojekyll
├── cahier.md (optionnel)
└── TODO.md (optionnel)
```

### Étape 3 : Uploader les fichiers

**Option A - Via l'interface GitHub (Simple) :**

1. Sur la page de votre nouveau dépôt GitHub
2. Cliquez sur **"uploading an existing file"**
3. Glissez-déposez tous les fichiers
4. Cliquez sur **"Commit changes"**

**Option B - Via Git (Recommandé) :**

Ouvrez un terminal dans le dossier du projet et exécutez :

```bash
# Initialiser Git
git init

# Ajouter tous les fichiers
git add .

# Premier commit
git commit -m "Déploiement initial - Application Couronne de Vie"

# Ajouter le remote (remplacez USERNAME et REPO_NAME)
git remote add origin https://github.com/USERNAME/REPO_NAME.git

# Pousser vers GitHub
git branch -M main
git push -u origin main
```

### Étape 4 : Activer GitHub Pages

1. Dans votre dépôt GitHub, allez dans **Settings** (Paramètres)
2. Dans le menu de gauche, cliquez sur **Pages**
3. Sous **Source** :
   - Sélectionnez **Branch: main**
   - Dossier : **/ (root)**
4. Cliquez sur **Save**

### Étape 5 : Accéder à votre application

1. Attendez 1-2 minutes
2. Votre application sera disponible à :
   ```
   https://VOTRE_USERNAME.github.io/NOM_DU_REPO/
   ```
3. Le lien exact apparaîtra dans **Settings > Pages**

## ✅ Vérification

Une fois déployé, vérifiez que :
- ✅ La page d'accueil s'affiche correctement
- ✅ Les icônes Font Awesome sont visibles
- ✅ Les graphiques Chart.js se chargent
- ✅ L'application fonctionne (ajouter une recette, etc.)

## 🔄 Mettre à jour l'application

Après avoir modifié des fichiers :

```bash
git add .
git commit -m "Description des modifications"
git push
```

Le site se mettra à jour automatiquement en quelques minutes.

## 🐛 Problèmes courants

### Le site ne se charge pas
- Vérifiez que le fichier `index.html` est à la racine
- Vérifiez que `.nojekyll` est présent
- Attendez 5 minutes et réessayez

### Les styles ne s'appliquent pas
- Vérifiez que `styles.css` est bien uploadé
- Videz le cache du navigateur (Ctrl+F5)

### Les graphiques ne s'affichent pas
- Vérifiez votre connexion internet (Chart.js vient d'un CDN)
- Ouvrez la console du navigateur (F12) pour voir les erreurs

### Les notifications ne fonctionnent pas
- GitHub Pages utilise HTTPS, donc c'est normal
- Autorisez les notifications dans votre navigateur

## 📞 Support

Si vous rencontrez des problèmes :
1. Vérifiez la console du navigateur (F12)
2. Consultez la documentation GitHub Pages
3. Ouvrez une issue sur le dépôt GitHub

---

**🎉 Félicitations !** Votre application est maintenant en ligne !

