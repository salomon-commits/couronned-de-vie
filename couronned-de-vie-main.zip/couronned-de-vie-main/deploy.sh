#!/bin/bash

# Script de déploiement rapide pour GitHub Pages
# Usage: ./deploy.sh "message de commit"

echo "🚀 Déploiement de l'application Couronne de Vie sur GitHub Pages"
echo ""

# Vérifier que Git est initialisé
if [ ! -d ".git" ]; then
    echo "📦 Initialisation du dépôt Git..."
    git init
fi

# Ajouter tous les fichiers
echo "📝 Ajout des fichiers..."
git add .

# Commit avec message
COMMIT_MSG=${1:-"Mise à jour de l'application"}
echo "💾 Commit: $COMMIT_MSG"
git commit -m "$COMMIT_MSG"

# Vérifier si le remote existe
if ! git remote | grep -q "origin"; then
    echo ""
    echo "⚠️  Aucun remote 'origin' trouvé."
    echo "📌 Ajoutez votre dépôt GitHub avec:"
    echo "   git remote add origin https://github.com/VOTRE_USERNAME/NOM_DU_REPO.git"
    echo ""
    read -p "Voulez-vous ajouter le remote maintenant? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        read -p "URL du dépôt GitHub: " REPO_URL
        git remote add origin "$REPO_URL"
    else
        echo "❌ Remote non ajouté. Ajoutez-le manuellement avant de pousser."
        exit 1
    fi
fi

# Pousser vers GitHub
echo "⬆️  Envoi vers GitHub..."
git branch -M main
git push -u origin main

echo ""
echo "✅ Déploiement terminé!"
echo "🌐 Votre application sera disponible sur GitHub Pages dans quelques minutes."
echo "📋 N'oubliez pas d'activer GitHub Pages dans Settings > Pages"

