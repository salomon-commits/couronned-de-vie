# Configuration Google Sheets

## 📋 Instructions pour configurer vos Google Sheets

### 1. Publier vos Google Sheets

Pour que l'application puisse lire vos données, vous devez publier vos Google Sheets :

1. Ouvrez votre Google Sheet
2. Allez dans **Fichier** > **Partager** > **Publier sur le Web**
3. Sélectionnez le format : **Valeurs séparées par des virgules (.csv)**
4. Cliquez sur **Publier**
5. Copiez l'URL générée

### 2. Obtenir l'URL CSV

L'URL doit être au format :
```
https://docs.google.com/spreadsheets/d/e/VOTRE_SHEET_ID/pub?gid=VOTRE_GID&single=true&output=csv
```

**Exemple d'URL pour RECETTES :**
```
https://docs.google.com/spreadsheets/d/e/2PACX-1vRvu0uZMCevHFKFdHK-gXJtZ37GAJDAtjgQUaDXv4Me2_e304OOJ0IrYl-jWq1sWfZdS4pc1b4voeyJ/pub?gid=2086630007&single=true&output=csv
```

### 3. Mettre à jour les URLs dans app.js

Ouvrez `app.js` et trouvez la section `GOOGLE_SHEETS_CONFIG` (ligne ~60).

Remplacez les URLs par les vôtres :

```javascript
const GOOGLE_SHEETS_CONFIG = {
    RECETTES: 'VOTRE_URL_RECETTES_CSV',
    TAXIS: 'VOTRE_URL_TAXIS_CSV',
    CHAUFFEURS: 'VOTRE_URL_CHAUFFEURS_CSV',
    COMMENTAIRES: 'VOTRE_URL_COMMENTAIRES_CSV'
};
```

### 4. Structure des colonnes requise

#### RECETTES.csv
- ID
- Date
- Matricule
- Recette Normale (FCFA)
- Montant Versé (FCFA)
- Résultat (FCFA)
- Statut
- Chauffeur
- Type de Course
- Remarques
- Timestamp

#### TAXIS.csv
- ID
- Matricule
- Marque/Modèle
- Propriétaire

#### CHAUFFEURS.csv
- ID
- Nom
- Téléphone
- Taxi Associé
- Photo URL

#### COMMENTAIRES_RAPPORTS.csv
- Mois
- Commentaires
- Date Création

### 5. Fonctionnement

- **Chargement automatique** : Les données sont chargées au démarrage de l'application
- **Rafraîchissement automatique** : Toutes les 5 minutes
- **Rafraîchissement manuel** : Bouton dans Paramètres > Synchronisation Google Sheets
- **Mode hors ligne** : Les données sont sauvegardées localement (IndexedDB) pour fonctionner hors ligne

### 6. Notes importantes

- Les Google Sheets doivent être **publiés publiquement** (en lecture seule)
- L'URL doit se terminer par `&output=csv`
- Les colonnes doivent correspondre exactement aux noms ci-dessus
- Les données sont synchronisées localement pour un accès hors ligne

---

**Besoin d'aide ?** Vérifiez que vos URLs sont correctes et que les Google Sheets sont bien publiés.

