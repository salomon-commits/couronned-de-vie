# Gestion des Recettes de Taxi

Application web complète pour la gestion des recettes quotidiennes de taxis, développée selon un cahier de charges détaillé.

## 🚀 Fonctionnalités

### Pages principales
- **Accueil** : Tableau de bord avec accès rapide aux différentes sections
- **Ajouter une Recette** : Enregistrement des recettes quotidiennes avec calcul automatique (déficit/surplus)
- **Liste des Recettes** : Consultation, recherche et filtrage des recettes
- **Détail d'une Recette** : Vue complète d'une recette avec possibilité de modification/suppression
- **Statistiques** : Graphiques et analyses des performances (journalières et mensuelles)
- **Gestion des Taxis** : CRUD complet pour les véhicules
- **Gestion des Chauffeurs** : CRUD complet pour les chauffeurs avec historique
- **Rapport Mensuel** : Génération de rapports détaillés avec export PDF
- **Paramètres** : Configuration des valeurs par défaut, couleurs, import/export de données

### Fonctionnalités techniques
- ✅ Stockage local avec IndexedDB (fonctionne hors ligne)
- ✅ Interface responsive (mobile-friendly)
- ✅ Graphiques interactifs avec Chart.js
- ✅ Export PDF avec jsPDF
- ✅ Import/Export JSON et CSV
- ✅ Notifications programmées avec rappels quotidiens
- ✅ Calcul automatique des résultats (déficit/surplus)
- ✅ Recherche et filtres avancés
- ✅ Tri avancé par colonnes (date, montant, matricule, etc.)
- ✅ Commentaires dans les rapports mensuels

## 📋 Prérequis

Aucun prérequis ! L'application fonctionne directement dans le navigateur.

## 🛠️ Installation locale

1. Clonez ou téléchargez ce dépôt
2. Ouvrez `index.html` dans votre navigateur web
3. C'est tout ! L'application fonctionne entièrement côté client

## 📦 Déploiement sur GitHub Pages

### 📋 Fichiers nécessaires

Assurez-vous d'avoir tous ces fichiers dans votre dépôt :
- ✅ `index.html` - Page principale
- ✅ `styles.css` - Styles de l'application
- ✅ `app.js` - Logique de l'application
- ✅ `README.md` - Documentation
- ✅ `.gitignore` - Fichiers à ignorer
- ✅ `.nojekyll` - Désactive Jekyll sur GitHub Pages
- ✅ `cahier.md` - Cahier de charges (optionnel)
- ✅ `TODO.md` - Liste des tâches (optionnel)

### Méthode 1 : Via l'interface GitHub (Recommandé pour débutants)

1. **Créer un nouveau dépôt sur GitHub**
   - Allez sur [github.com](https://github.com)
   - Cliquez sur "New repository"
   - Nommez-le (ex: `gestion-recettes-taxi` ou `couronne-de-vie`)
   - Choisissez Public ou Private
   - **Ne cochez PAS** "Initialize with README" (vous avez déjà un README)

2. **Uploadez tous les fichiers**
   - Cliquez sur "uploading an existing file"
   - Glissez-déposez tous les fichiers du projet :
     - `index.html`
     - `styles.css`
     - `app.js`
     - `README.md`
     - `.gitignore`
     - `.nojekyll`
   - Cliquez sur "Commit changes"

3. **Activer GitHub Pages**
   - Allez dans **Settings** (Paramètres) du dépôt
   - Dans le menu de gauche, cliquez sur **Pages**
   - Sous **Source**, sélectionnez la branche `main` (ou `master`)
   - Le dossier doit être `/ (root)`
   - Cliquez sur **Save**

4. **Accéder à votre application**
   - Attendez 1-2 minutes pour le déploiement
   - Votre application sera disponible à :
     `https://votre-username.github.io/nom-du-repo/`
   - Le lien apparaîtra dans la section Pages des Settings

### Méthode 2 : Via Git en ligne de commande (Recommandé)

```bash
# 1. Initialiser le dépôt Git (si pas déjà fait)
git init

# 2. Ajouter tous les fichiers
git add .

# 3. Faire le premier commit
git commit -m "Initial commit - Application de gestion de recettes de taxi Couronne de Vie"

# 4. Créer le dépôt sur GitHub d'abord, puis ajouter le remote
# Remplacez VOTRE_USERNAME et NOM_DU_REPO par vos valeurs
git remote add origin https://github.com/VOTRE_USERNAME/NOM_DU_REPO.git

# 5. Renommer la branche en main (si nécessaire)
git branch -M main

# 6. Pousser vers GitHub
git push -u origin main
```

**Ensuite :**
- Allez dans **Settings** > **Pages** de votre dépôt GitHub
- Sélectionnez la branche `main` comme source
- Votre site sera déployé automatiquement !

### 🔄 Mises à jour futures

Pour mettre à jour l'application après des modifications :

```bash
# Ajouter les fichiers modifiés
git add .

# Faire un commit
git commit -m "Description des modifications"

# Pousser vers GitHub
git push
```

GitHub Pages mettra à jour automatiquement le site en quelques minutes.

### ⚠️ Notes importantes pour GitHub Pages

- **HTTPS requis** : GitHub Pages utilise HTTPS, ce qui est nécessaire pour certaines fonctionnalités (notifications, Service Workers)
- **Délai de déploiement** : Le site peut prendre 1-5 minutes à se mettre à jour après un push
- **URL personnalisée** : Vous pouvez utiliser un nom de domaine personnalisé dans les Settings > Pages
- **Limites** : 
  - 1 Go de stockage par dépôt
  - 100 Go de bande passante par mois
  - 10 builds par heure

## 📱 Utilisation

### Première utilisation

1. **Ajoutez des taxis** : Allez dans "Gestion des Taxis" et ajoutez vos véhicules
2. **Ajoutez des chauffeurs** : Allez dans "Gestion des Chauffeurs" et enregistrez vos chauffeurs
3. **Configurez les valeurs par défaut** : Dans "Paramètres", définissez les montants de recette par défaut (ex: 9000, 12000, 15000 FCFA)

### Enregistrer une recette

1. Cliquez sur "Ajouter une Recette"
2. Sélectionnez le matricule du taxi
3. La date est remplie automatiquement (modifiable si besoin)
4. Entrez la recette normale ou utilisez les boutons rapides
5. Entrez le montant réellement versé
6. Sélectionnez le chauffeur
7. Le résultat (déficit/surplus) s'affiche automatiquement
8. Cliquez sur "Enregistrer"

### Consulter les statistiques

- Les statistiques se mettent à jour automatiquement
- Graphiques des 7 derniers jours
- Classement des chauffeurs par performance
- Totaux mensuels et journaliers

### Exporter les données

- **JSON** : Export complet de toutes les données (recettes, taxis, chauffeurs, paramètres)
- **CSV** : Export des recettes uniquement (compatible Excel)
- **PDF** : Rapport mensuel détaillé depuis la page "Rapport Mensuel"

## 🔧 Personnalisation

### Modifier les couleurs

1. Allez dans "Paramètres"
2. Modifiez les couleurs principale et secondaire
3. Cliquez sur "Appliquer"

### Modifier les valeurs par défaut

1. Allez dans "Paramètres"
2. Modifiez les trois valeurs de recette par défaut
3. Cliquez sur "Enregistrer"

## 💾 Sauvegarde des données

- Toutes les données sont stockées localement dans votre navigateur (IndexedDB)
- Les données persistent même après fermeture du navigateur
- Pour sauvegarder ailleurs, utilisez l'export JSON/CSV dans les paramètres
- Pour restaurer, utilisez l'import JSON/CSV

## 🌐 Compatibilité

- ✅ Chrome/Edge (recommandé)
- ✅ Firefox
- ✅ Safari
- ✅ Opéra
- ✅ Navigateurs mobiles (iOS Safari, Chrome Mobile)

## 📝 Notes importantes

- Les données sont stockées uniquement dans votre navigateur
- Pour utiliser sur plusieurs appareils, exportez et importez les données
- Les notifications nécessitent l'autorisation du navigateur
- L'application fonctionne entièrement hors ligne après le premier chargement
- **Application déployée sur GitHub Pages** : Les données sont synchronisées automatiquement depuis Google Sheets
- Pour mettre à jour l'application, consultez le fichier `MISE_A_JOUR.md`

## 🐛 Dépannage

### Les données ne s'affichent pas
- Vérifiez que JavaScript est activé dans votre navigateur
- Ouvrez la console du navigateur (F12) pour voir les erreurs

### L'export ne fonctionne pas
- Vérifiez que les popups ne sont pas bloquées
- Essayez avec un autre navigateur

### Les graphiques ne s'affichent pas
- Vérifiez votre connexion internet (Chart.js est chargé depuis un CDN)
- Ou téléchargez Chart.js localement

## 📄 Licence

Ce projet est libre d'utilisation pour un usage personnel ou commercial.

## 👨‍💻 Support

Pour toute question ou problème, ouvrez une issue sur GitHub.

---

**Développé selon le cahier de charges fourni** - Application de gestion de recettes de taxi complète et fonctionnelle.

