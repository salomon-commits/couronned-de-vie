# Structure des Fichiers Excel pour Couronne de Vie

## 📋 Description

Ces fichiers CSV peuvent être ouverts directement dans Microsoft Excel ou Google Sheets pour servir de base de données pour l'application de gestion des recettes de taxi.

## 📁 Fichiers disponibles

### COURONNE_DE_VIE_DONNEES_COMPLET.csv (Recommandé)
**Fichier CSV unique** contenant toutes les données organisées en sections clairement identifiables.

Le fichier contient 4 sections séparées par des en-têtes `=== SECTION ===` :
1. **RECETTES** - Toutes les recettes quotidiennes
2. **TAXIS** - Liste des véhicules
3. **CHAUFFEURS** - Liste des chauffeurs
4. **COMMENTAIRES** - Commentaires mensuels

**Avantage** : Structure claire et facile à lire, peut être facilement séparé en feuilles Excel.

### COURONNE_DE_VIE_DONNEES.csv (Format unifié)
**Fichier CSV avec toutes les données dans un format unifié** avec une colonne "Section" pour identifier le type de données.

**Avantage** : Toutes les données dans un seul format, facile à filtrer par section dans Excel.

### Sections du fichier

#### 1. SECTION: RECETTES
**Feuille principale** - Contient toutes les recettes quotidiennes

**Colonnes :**
- **ID** : Identifiant unique (numéro auto)
- **Date** : Date de la recette (format: AAAA-MM-JJ)
- **Matricule** : Numéro d'immatriculation du taxi
- **Recette Normale (FCFA)** : Montant attendu
- **Montant Versé (FCFA)** : Montant réellement versé
- **Résultat (FCFA)** : Calcul automatique (Montant Versé - Recette Normale)
- **Statut** : Déficit / Correct / Surplus (formule conditionnelle)
- **Chauffeur** : Nom du chauffeur
- **Type de Course** : Ville / Aéroport / Longue distance / Autre
- **Remarques** : Notes et observations
- **Timestamp** : Horodatage de création (optionnel)

#### 2. SECTION: TAXIS
**Gestion des véhicules**

**Colonnes :**
- **ID** : Identifiant unique
- **Matricule** : Numéro d'immatriculation (unique)
- **Marque/Modèle** : Marque et modèle du véhicule
- **Propriétaire** : Toujours "COURONNE DE VIE"

#### 3. SECTION: CHAUFFEURS
**Gestion des chauffeurs**

**Colonnes :**
- **ID** : Identifiant unique
- **Nom** : Nom complet du chauffeur
- **Téléphone** : Numéro de téléphone
- **Taxi Associé** : Matricule du taxi associé
- **Photo URL** : Lien vers la photo (optionnel)

#### 4. SECTION: COMMENTAIRES_RAPPORTS
**Commentaires mensuels**

**Colonnes :**
- **Mois** : Format: AAAA-MM (ex: 2024-01)
- **Commentaires** : Observations du mois
- **Date Création** : Date de création du commentaire

## 🔧 Comment utiliser dans Excel

### Option 1 : Ouvrir directement
1. Double-cliquez sur le fichier `COURONNE_DE_VIE_DONNEES.csv`
2. Excel s'ouvrira avec toutes les données
3. Les sections sont séparées par des en-têtes `=== SECTION: ... ===`
4. Sauvegardez en format Excel (.xlsx) si nécessaire

### Option 2 : Séparer en feuilles Excel (Recommandé)
Pour mieux organiser les données, créez un classeur Excel avec plusieurs feuilles :

1. Ouvrez Excel et créez un nouveau classeur
2. Ouvrez `COURONNE_DE_VIE_DONNEES.csv` dans un éditeur de texte
3. Copiez chaque section dans une feuille séparée :
   - **Feuille 1 "RECETTES"** : Copiez les lignes de la section RECETTES (sans l'en-tête de section)
   - **Feuille 2 "TAXIS"** : Copiez les lignes de la section TAXIS
   - **Feuille 3 "CHAUFFEURS"** : Copiez les lignes de la section CHAUFFEURS
   - **Feuille 4 "COMMENTAIRES"** : Copiez les lignes de la section COMMENTAIRES_RAPPORTS

### Option 3 : Utiliser Power Query (Excel avancé)
1. Ouvrez Excel
2. Allez dans **Données** > **Obtenir des données** > **Depuis un fichier** > **Depuis un texte/CSV**
3. Sélectionnez `COURONNE_DE_VIE_DONNEES.csv`
4. Configurez le délimiteur (virgule) et l'encodage (UTF-8)
5. Utilisez Power Query pour séparer les sections en différentes tables

## 📊 Formules Excel recommandées

### Dans RECETTES.csv

**Colonne Résultat (F) :**
```
=E2-D2
```
(Calcul automatique : Montant Versé - Recette Normale)

**Colonne Statut (G) :**
```
=SI(F2<0;"Déficit";SI(F2=0;"Correct";"Surplus"))
```
(Affiche le statut selon le résultat)

### Totaux en bas du tableau

**Total Recettes Normales :**
```
=SOMME(D:D)
```

**Total Montants Versés :**
```
=SOMME(E:E)
```

**Total Déficits :**
```
=SOMME.SI(F:F;"<0";F:F)
```

**Total Surplus :**
```
=SOMME.SI(F:F;">0";F:F)
```

## 🔄 Synchronisation avec l'application

Pour synchroniser les données entre Excel et l'application web :

1. **Export depuis l'application** : Utilisez la fonction "Exporter CSV" dans les Paramètres
2. **Import vers Excel** : Ouvrez le fichier CSV exporté dans Excel
3. **Modifications dans Excel** : Modifiez les données dans Excel
4. **Import vers l'application** : Utilisez la fonction "Importer CSV" dans les Paramètres

## ⚠️ Notes importantes

- Les fichiers CSV utilisent la virgule (,) comme séparateur
- L'encodage est UTF-8 pour supporter les caractères spéciaux
- Les dates doivent être au format AAAA-MM-JJ
- Les montants sont en FCFA (Franc CFA)
- Le matricule doit être unique dans TAXIS.csv

## 📝 Exemple d'utilisation

1. Ouvrez RECETTES.csv dans Excel
2. Ajoutez vos données quotidiennes
3. Les formules calculeront automatiquement les résultats
4. Utilisez les filtres Excel pour analyser les données
5. Créez des graphiques pour visualiser les performances

---

**Développé pour Couronne de Vie - Gestion des Recettes de Taxi**

