# 🔄 Guide de Mise à Jour - GitHub Pages

## 📍 Application en ligne

L'application **Couronne de Vie** est actuellement déployée sur **GitHub Pages** et accessible en ligne.

## 🚀 Comment mettre à jour l'application

### Étape 1 : Mettre à jour les fichiers locaux

1. Modifiez les fichiers nécessaires (`index.html`, `app.js`, `styles.css`, etc.)
2. Testez localement en ouvrant `index.html` dans votre navigateur

### Étape 2 : Committer les changements

```bash
# Vérifier les fichiers modifiés
git status

# Ajouter les fichiers modifiés
git add .

# Créer un commit avec une description
git commit -m "Description des modifications (ex: Ajout synchronisation Google Sheets)"

# Pousser vers GitHub
git push origin main
```

### Étape 3 : Vérifier le déploiement

1. Attendez 1-2 minutes pour que GitHub Pages se mette à jour
2. Vérifiez votre site à l'adresse : `https://votre-username.github.io/nom-du-repo/`
3. Videz le cache de votre navigateur (Ctrl+F5 ou Cmd+Shift+R) si nécessaire

## ⚙️ Configuration actuelle

### URLs Google Sheets configurées

Toutes les URLs sont configurées dans `app.js` :

- ✅ **RECETTES** : URL configurée
- ✅ **TAXIS** : URL configurée  
- ✅ **CHAUFFEURS** : URL configurée
- ✅ **COMMENTAIRES** : URL configurée

### Fonctionnalités déployées

- ✅ Système d'authentification (Lecteur/Gestionnaire)
- ✅ Lecture automatique depuis Google Sheets
- ✅ Bouton de contrôle de réception des données
- ✅ Modification des données côté gestionnaire
- ✅ Synchronisation automatique toutes les 5 minutes
- ✅ Mode hors ligne avec IndexedDB

## 📝 Notes importantes pour GitHub Pages

### HTTPS requis

- GitHub Pages utilise HTTPS automatiquement
- Les requêtes vers Google Sheets fonctionnent en HTTPS
- Aucune configuration CORS supplémentaire nécessaire

### Cache du navigateur

- Les utilisateurs doivent parfois vider leur cache pour voir les dernières modifications
- Utilisez Ctrl+F5 (Windows) ou Cmd+Shift+R (Mac) pour forcer le rechargement

### Mise à jour automatique

- Les données Google Sheets sont rafraîchies toutes les 5 minutes
- Le bouton de rafraîchissement manuel est disponible dans les Paramètres

## 🔧 Dépannage

### L'application ne se met pas à jour

1. Vérifiez que les changements sont bien pushés sur GitHub
2. Attendez 2-3 minutes (délai de déploiement GitHub Pages)
3. Videz le cache de votre navigateur
4. Vérifiez dans les Settings > Pages de votre repo GitHub que le déploiement est réussi

### Les données Google Sheets ne se chargent pas

1. Vérifiez que les Google Sheets sont bien publiés publiquement
2. Vérifiez les URLs dans `app.js` (section `GOOGLE_SHEETS_CONFIG`)
3. Ouvrez la console du navigateur (F12) pour voir les erreurs
4. Vérifiez que les URLs se terminent par `&output=csv`

### Les modifications ne s'enregistrent pas

- Les modifications sont stockées localement (IndexedDB)
- Pour synchroniser avec Google Sheets, exportez les données CSV depuis l'application
- Mettez à jour manuellement vos Google Sheets avec les données exportées

## 📞 Support

Pour toute question ou problème de déploiement, consultez la documentation GitHub Pages ou ouvrez une issue sur GitHub.

---

**Dernière mise à jour** : Configuration Google Sheets complète avec contrôle de réception pour lecteurs

